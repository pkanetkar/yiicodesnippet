<?php

namespace app\models;

use nepstor\validators\DateTimeCompareValidator;
use Yii;

/**
 * This is the model class for table "invoice".
 *
 * @property integer $id
 * @property integer $appointment_id
 * @property integer $created_by
 * @property string $created_at
 * @property string $updated_at
 */
class Invoice extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'invoice';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['appointment_id', 'client_id', 'created_at'], 'required'],
            [['appointment_id', 'created_by'], 'integer'],
            [['created_at', 'appointment_id', 'client_id', 'amount', 'paid_amount'], 'safe'],
            ['created_at', DateTimeCompareValidator::className(), 'compareValue' => date('Y-m-d'), 'operator' => '>=', 'format' => 'Y-m-d'],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Invoice Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTasks() {
        // Invoice has_many Task via invoice.id -> invoice_id
        return $this->hasMany(InvoiceTasks::className(), ['invoice_id' => 'id']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Invoice Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAppointment() {
        // Invoice has_many Task via invoice.id -> invoice_id
        return $this->hasOne(Appointment::className(), ['id' => 'appointment_id']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Invoice Email model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmails() {
        // Invoice has_many email via id -> invoice_id
        return $this->hasMany(InvoiceEmails::className(), ['invoice_id' => 'id']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Client info model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClientInfo() {
        // Vendor has_one Supply item via supply.manufacturerVendor -> vendor_id
        return $this->hasOne(ClientInfo::className(), ['id' => 'client_id']);
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'appointment_id' => 'Appointment ID',
            'client_id' => 'Client',
            'created_by' => 'Created By',
            'created_at' => 'Date',
            'updated_at' => 'Updated At',
        ];
    }

}
