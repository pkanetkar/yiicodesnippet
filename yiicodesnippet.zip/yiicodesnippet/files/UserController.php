<?php

namespace app\controllers;

use Yii;
use app\models\User;
use app\models\UserSearch;
use app\models\IntervieweeImport;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\Package;
use app\models\UserPermissions;
use yii\web\UploadedFile;
use app\models\Location;
use yii\imagine\Image;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * UserController implements the CRUD actions for User model.
 */
class UserController extends Controller {

    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
            'access' => [
                'class' => \yii\filters\AccessControl::className(),
                'only' => ['index', 'create', 'update', 'view', 'delete', 'interviewee-list'],
                'rules' => [
                    [
                        'actions' => ['index', 'create', 'view', 'delete', 'update', 'interviewee-list'],
                        'allow' => true,
                        'roles' => ['@'],
                        'matchCallback' => function ($rule, $action) {
                    return true;
                }
                    ],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all User models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        return $this->render('index', [
                    'dataProvider' => $dataProvider,
                    'searchModel' => $searchModel
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single User model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $permissionSet = array();
        if ($this->getUser()->user_type == 'admin' && $this->getUser()->parent_id == 0) {
            // gathering permission set
            $defaultPackage = Package::find()->all();
            foreach ($defaultPackage as $df) {
                $permissionSet['info'][$df->id] = $df->package_name;
                $permissionSet['data'][$df->id] = $this->getPermissionValue($df->id, $id);
            }
        }
        return $this->render('view', [
                    'model' => $this->findModel($id), 'permissionSet' => $permissionSet,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new User();
        $defaultPackage = Package::find()->all();
        $permissionSet = array();
        foreach ($defaultPackage as $df) {
            $permissionSet['info'][$df->id] = $df->package_name;
            $permissionSet['data'][$df->id] = 0;
        }

        if ($model->load(Yii::$app->request->post())) {

            $img = UploadedFile::getInstance($model, 'profile_img');
            if (empty($img)) {
                $model->profile_img = 'no_Image.png';
            } else {
                $file_name = time().$img;
                $model->profile_img = $file_name;
            }
            
            $password = $this->randomPassword();
            $model->password_hash = Yii::$app->security->generatePasswordHash($password);

            if ($model->save()) {
                /* save user privileges */
                $post = Yii::$app->request->post();
                $permission = $post['permission'];
                $this->saveUserPermission($defaultPackage, $permission, $model->id, true);

                User::sendAccountRegistrationMail($model->email, $password);
                Yii::$app->session->setFlash('success', Yii::t('app', 'User created.'));
                if (!empty($img)) {
                    $img->saveAs('uploads/user/' . $file_name);
                    Image::thumbnail('uploads/user/' . $file_name, 120, 120)
                    ->save(Yii::getAlias('uploads/user/thumb/' . $file_name), ['quality' => 80]);
                }
                return $this->redirect(['index']);
            }
        }
        return $this->render('create', [
                    'model' => $model, 'permissionSet' => $permissionSet,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $oldFileName = $model->profile_img;
        $model->scenario = 'update';
        $permissionSet = array();
        if ($model->load(Yii::$app->request->post())) {
            $img = UploadedFile::getInstance($model, 'profile_img');
            if (empty($img)) {
                $model->profile_img = $oldFileName;
            } else {
                $file_name = time().$img;
                $model->profile_img = $file_name;
            }
            if ($model->save()) {
                if (!empty($img)) {
                    $img->saveAs('uploads/user/' . $file_name);
                    Image::thumbnail('uploads/user/' . $file_name, 120, 120)
                    ->save(Yii::getAlias('uploads/user/thumb/' . $file_name), ['quality' => 80]);
                }
                Yii::$app->session->setFlash('success', Yii::t('app', 'User updated.'));
                return $this->redirect(['index']);
            }
        }

        return $this->render('update', [
                    'model' => $model, 'permissionSet' => $permissionSet,
        ]);
    }

     /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', Yii::t('app', 'User deleted.'));
        return $this->redirect(['index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all Users with user type interviewer.
     * @return mixed
     */
    public function actionInterviewerList() {
        $user = $this->getUser();
        $query = User::find()->joinWith('interviewer')->where("user_type = 'interviewer'");

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                \Yii::$app->params['PAGINATION_SIZE'],
            ],
            'sort' => [
                'attributes' => [
                    'username',
                    'email',
                    'status',
                    'experience' => [
                        'desc' => ['interviewer.experience' => SORT_DESC],
                        'asc' => ['interviewer.experience' => SORT_ASC]
                    ],
                ]
            ],
        ]);

        return $this->render('interviewer-list', [
                    'dataProvider' => $dataProvider,
        ]);
    }
  
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the User model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return User the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = User::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
