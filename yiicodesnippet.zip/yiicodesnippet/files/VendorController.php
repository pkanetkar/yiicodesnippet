<?php

namespace app\controllers;

use Yii;
use app\models\Vendor;
use app\models\Department;
use app\models\Model;
use app\models\VendorSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\ArrayHelper;
use app\models\Location;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * VendorController implements the CRUD actions for Vendor model.
 */
class VendorController extends Controller {

    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all Vendor models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new VendorSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single Vendor model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new Vendor model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $modelVendor = new Vendor(['scenario' => 'create']);
        $modelDepartment = [new Department];

        if ($modelVendor->load(Yii::$app->request->post())) {

            $modelDepartment = Model::createMultiple(Department::classname());
            Model::loadMultiple($modelDepartment, Yii::$app->request->post());

            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelDepartment), ActiveForm::validate($modelVendor)
                );
            }

            // validate all models
            $valid = $modelVendor->validate();
            $valid = Model::validateMultiple($modelDepartment) && $valid;

            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    if ($flag = $modelVendor->save(false)) {
                        foreach ($modelDepartment as $modelDepartment) {
                            $modelDepartment->vendor_id = $modelVendor->vendor_id;
                            if (!($flag = $modelDepartment->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Vendor created.'));
                        return $this->redirect(['index']);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }
        } else {

            return $this->render('create', [
                        'modelVendor' => $modelVendor,
                        'modelDepartment' => (empty($modelDepartment)) ? [new Department] : $modelDepartment,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing Vendor model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $modelVendor = $this->findModel($id);
        $modelVendor->scenario = 'update';
        $modelDepartment = $modelVendor->departments;
        if ($modelVendor->load(Yii::$app->request->post())) {
            $oldIDs = ArrayHelper::map($modelDepartment, 'id', 'id');
            $modelDepartment = Model::createMultiple(Department::classname(), $modelDepartment);
            Model::loadMultiple($modelDepartment, Yii::$app->request->post());
            $deletedIDs = array_diff($oldIDs, array_filter(ArrayHelper::map($modelDepartment, 'id', 'id')));
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelDepartment), ActiveForm::validate($modelVendor)
                );
            }

            // validate all models
            $valid = $modelVendor->validate();
            $valid = Model::validateMultiple($modelDepartment) && $valid;

            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    if ($flag = $modelVendor->save(false)) {
                        if (!empty($deletedIDs)) {
                            Department::deleteAll(['id' => $deletedIDs]);
                        }
                        foreach ($modelDepartment as $modelDepartment) {
                            $modelDepartment->vendor_id = $modelVendor->vendor_id;
                            if (!($flag = $modelDepartment->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Vendor updated.'));
                        return $this->redirect(['index']);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }
        } else {
            return $this->render('update', [
                        'modelVendor' => $modelVendor,
                        'modelDepartment' => (empty($modelDepartment)) ? [new Department] : $modelDepartment,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Deletes an existing Vendor model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', Yii::t('app', 'Vendor deleted.'));
        return $this->redirect(['index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the Vendor model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Vendor the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Vendor::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * View Product
     * @param int $id vendor id
     * @return array $model
     *      
     */
    public function actionProducts($id) {
        //Get product data
        $products = \app\models\Supply::find()->where(['manufacturerVendor' => $id])->asArray()->all();
        return $this->renderPartial('_products', [
                    'products' => $products,
        ]);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Get city list
     * User start searching on city dropdown it will generate list of city
     * @param string $q int $id
     * @return json $citylist
     *      
     */
    public function actionCitylist($q = null, $id = null) {
         //response in json format
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $result = Yii::$app->db->createCommand('Select id, CONCAT(city," ", "(", zipcode ,")" ) AS text From location Where city like "%' . $q . '%"'.Yii::$app->params['DROPDOWN_SIZE'])->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => Location::find($id)->city];
        }
        return $out;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Get state list
     * User start searching on state dropdown it will generate list of state
     * @param string $q int $id
     * @return json $statelist
     *      
     */
    public function actionStatelist($q = null, $id = null) {
        //response in json format
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $result = Yii::$app->db->createCommand('Select DISTINCT state as text,state as id From location Where state like "%' . $q . '%"'.Yii::$app->params['DROPDOWN_SIZE'])->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => Location::find($id)->state];
        }
        return $out;
    }

}
