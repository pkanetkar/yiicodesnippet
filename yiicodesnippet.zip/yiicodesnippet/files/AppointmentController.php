<?php

namespace app\controllers;

use Yii;
use app\models\Appointment;
use app\models\AppointmentSearch;
use app\models\AppointmentEquipmentList;
use app\models\AppointmentShoppingList;
use yii\web\Controller;
use app\models\Model;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\ClientInfo;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;
use app\models\FormLetters;
use app\models\Messages;
use app\models\AppointmentTasks;
use mPDF;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * AppointmentController implements the CRUD actions for Appointment model.
 */
class AppointmentController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all Appointment models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new AppointmentSearch();
         Yii::$app->session->remove('duplicate');
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single Appointment model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $model = $this->findModel($id);
        $client_info = ClientInfo::findOne($model->client_id);
        $properties = ArrayHelper::map($client_info->properties, 'id', 'name');
        $emails = ArrayHelper::map($client_info->mails, 'id', 'subject');
        $modelTask = $model->tasks;
        return $this->render('view', [
                    'model' => $this->findModel($id),
                    'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                    'client_info' => $client_info,
                    'properties' => $properties,
                    'emails' => $emails,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new Appointment model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($id = null,$type= null) {
        $model = new Appointment();
        $model->scenario = 'create';
        $modelTask = [new AppointmentTasks];
        $modelSupply = [new AppointmentShoppingList];
        $modelEquipment = [new AppointmentEquipmentList];
        $client_info = [];
        $properties = [];
        $emails = [];
        if ($id && Yii::$app->session->get('duplicate')) {
            $existing_model = $this->findModel($id);
            $model->attributes = $existing_model->attributes;
            $model->id = null;
            $client_info = ClientInfo::findOne($model->client_id);
            $properties = ArrayHelper::map($client_info->properties, 'id', 'name');
            $emails = ArrayHelper::map($client_info->mails, 'id', 'subject');
            $modelTask = $existing_model->tasks;
            $modelSupply = $existing_model->supply;
            $modelEquipment = $existing_model->equipment;
        } else if ($id) {
           
            $client_info = ClientInfo::findOne($id);
            $properties = ArrayHelper::map($client_info->properties, 'id', 'name');
            $emails = ArrayHelper::map($client_info->mails, 'id', 'subject');
        }

        if ($model->load(Yii::$app->request->post())) {
             //Appointment Task
            $modelTask = Model::createMultiple(AppointmentTasks::classname());
            Model::loadMultiple($modelTask, Yii::$app->request->post());
            //Supply
            $modelSupply = Model::createMultiple(AppointmentShoppingList::classname());
            Model::loadMultiple($modelSupply, Yii::$app->request->post());
            //Equipment
            $modelEquipment = Model::createMultiple(AppointmentEquipmentList::classname());
            Model::loadMultiple($modelEquipment, Yii::$app->request->post());

            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelEquipment),ActiveForm::validateMultiple($modelSupply),ActiveForm::validateMultiple($modelTask), ActiveForm::validate($model)
                );
            }
            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelTask) && $valid && Model::validateMultiple($modelSupply)&& Model::validateMultiple($modelEquipment);
            if (Yii::$app->session->get('duplicate')) {
                $model->parent_id = Yii::$app->session->get('duplicate');
            }
            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                //convert date in mysql format
                $appointment = Yii::$app->request->post('Appointment');
                $model->start_time = date("H:i:s", strtotime($appointment['start_time']));
                $model->end_time = date("H:i:s", strtotime($appointment['end_time']));
                try {
                    if ($flag = $model->save(false)) {
                        //Service / Task
                        foreach ($modelTask as $modelTask) {
                            $modelTask->a_id = $model->id;
                            if (!($flag = $modelTask->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        //Supply / Supply items
                        foreach ($modelSupply as $modelSupply) {
                            $modelSupply->appointment_id = $model->id;
                            if (!($flag = $modelSupply->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        //Equipment / Garage items
                        foreach ($modelEquipment as $modelEquipment) {
                            $modelEquipment->appointment_id = $model->id;
                            if (!($flag = $modelEquipment->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        if(($model->status=='unconfirmed' ||$model->status=='confirmed')&& $model->type=='estimate' ){
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment created.'));
                            return $this->redirect(['preview', 'id' => $model->id]);
                        }
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment created.'));
                        return $this->redirect(['send', 'id' => $model->id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            } else {
                return $this->render('create', [
                            'model' => $model,
                            'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                            'modelSupply' => (empty($modelSupply)) ? [new AppointmentShoppingList] : $modelSupply,
                            'modelEquipment' => (empty($modelEquipment)) ? [new AppointmentEquipmentList] : $modelEquipment,
                            'client_info' => $client_info,
                            'properties' => $properties,
                            'emails' => $emails,
                            'type'=>$type,
                ]);
            }
        } else {
            return $this->render('create', [
                        'model' => $model,
                        'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                        'modelSupply' => (empty($modelSupply)) ? [new AppointmentShoppingList] : $modelSupply,
                        'modelEquipment' => (empty($modelEquipment)) ? [new AppointmentEquipmentList] : $modelEquipment,
                        'client_info' => $client_info,
                        'properties' => $properties,
                        'emails' => $emails,
                        'type'=>$type,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing Appointment model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $client_info = ClientInfo::findOne($model->client_id);
        $properties = ArrayHelper::map($client_info->properties, 'id', 'name');
        $emails = ArrayHelper::map($client_info->mails, 'id', 'subject');
        $modelTask = $model->tasks;
        $modelSupply = $model->supply;
        $modelEquipment = $model->equipment;
        $duplicate = 0;
        if ($model->load(Yii::$app->request->post())) {
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelEquipment),ActiveForm::validateMultiple($modelSupply),ActiveForm::validateMultiple($modelTask), ActiveForm::validate($model)
                );
            }
            //Appointment Task / Service
            $oldIDs = ArrayHelper::map($modelTask, 'id', 'id');
            $modelTask = Model::createMultiple(AppointmentTasks::classname(), $modelTask);
            
            Model::loadMultiple($modelTask, Yii::$app->request->post());
            $deletedIDs = array_diff($oldIDs, array_filter(ArrayHelper::map($modelTask, 'id', 'id')));
            
            //Appointment Supply 
            $oldSupplyIDs = ArrayHelper::map($modelSupply, 'id', 'id');
            $modelSupply = Model::createMultiple(AppointmentShoppingList::classname(), $modelSupply);
            
            Model::loadMultiple($modelSupply, Yii::$app->request->post());
            $deletedSupplyIDs = array_diff($oldSupplyIDs, array_filter(ArrayHelper::map($modelSupply, 'id', 'id')));
            
            //Appointment Equipment / Garage item 
            $oldEquipmentIDs = ArrayHelper::map($modelEquipment, 'id', 'id');
            $modelEquipment = Model::createMultiple(AppointmentEquipmentList::classname(), $modelEquipment);
            
            Model::loadMultiple($modelEquipment, Yii::$app->request->post());
            $deletedEquipmentIDs = array_diff($oldEquipmentIDs, array_filter(ArrayHelper::map($modelEquipment, 'id', 'id')));

            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelTask) && $valid && Model::validateMultiple($modelSupply)&& Model::validateMultiple($modelEquipment);
            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    //convert date in mysql format
                    $appointment = Yii::$app->request->post('Appointment');
                    $model->start_time = date("H:i:s", strtotime($appointment['start_time']));
                    $model->end_time = date("H:i:s", strtotime($appointment['end_time']));
                  
                    if ($flag = $model->save(false)) {
                        //Service / Task
                         if (!empty($deletedIDs)) {
                            AppointmentTasks::deleteAll(['id' => $deletedIDs]);
                        }
                        foreach ($modelTask as $modelTask) {
                            $modelTask->a_id = $model->id;
                            if (!($flag = $modelTask->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        //Supply / Supply items
                         if (!empty($deletedSupplyIDs)) {
                             AppointmentShoppingList::deleteAll(['id' => $deletedSupplyIDs]);
                        }
                        foreach ($modelSupply as $modelSupply) {
                            $modelSupply->appointment_id = $model->id;
                            if (!($flag = $modelSupply->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        //Equipment / Garage items
                         if (!empty($deletedEquipmentIDs)) {
                             AppointmentEquipmentList::deleteAll(['id' => $deletedEquipmentIDs]);
                        }
                        foreach ($modelEquipment as $modelEquipment) {
                            $modelEquipment->appointment_id = $model->id;
                            if (!($flag = $modelEquipment->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        if(($model->status=='unconfirmed' ||$model->status=='confirmed')&& $model->type=='estimate' ){
                           Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment updated.'));
                           return $this->redirect(['preview', 'id' => $model->id]);
                        }
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment updated.'));
                        return $this->redirect(['send', 'id' => $model->id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            } else {
                return $this->render('update', [
                            'model' => $model,
                            'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                            'modelSupply' => (empty($modelSupply)) ? [new AppointmentShoppingList] : $modelSupply,
                            'modelEquipment' => (empty($modelEquipment)) ? [new AppointmentEquipmentList] : $modelEquipment,
                            'client_info' => $client_info,
                            'properties' => $properties,
                            'duplicate' => $duplicate,
                            'emails' => $emails,
                ]);
            }
        } else {
            return $this->render('update', [
                        'model' => $model,
                        'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                        'modelSupply' => (empty($modelSupply)) ? [new AppointmentShoppingList] : $modelSupply,
                        'modelEquipment' => (empty($modelEquipment)) ? [new AppointmentEquipmentList] : $modelEquipment,
                        'client_info' => $client_info,
                        'properties' => $properties,
                        'duplicate' => $duplicate,
                        'emails' => $emails,
            ]);
        }
    }
     /**
      * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Show priview for appointment.
     * create view of appointment.
     * @return mixed
     */
    public function actionPreview($id = null) {
        SettingController::actionSetSetting();       
        $appointment =  $this->findModel($id);
        $model = new Messages;
        $client_info = ClientInfo::findOne($appointment->client_id);
        $emails = ArrayHelper::map($client_info->clientEmails, 'client_email', 'name');
        $formLetters = ArrayHelper::map(FormLetters::find()->all(), 'id', 'name');
        // get your HTML raw content without any layouts or scripts
        $mpdf = new mPDF();
        $stylesheet = file_get_contents('css/style.css');
        $mpdf->WriteHTML($stylesheet, 1);
        $mpdf->WriteHTML($this->renderPartial('_pdf', ['model' => $model,
                    'invoice' => $invoice,
                    'client_info' => $client_info,
                    'appointment' => $appointment,
                    'formLetters' => $formLetters]), 2);

        $mpdf->Output(\Yii::$app->request->BaseUrl . 'uploads/estimates/estimate-' . $id . '.pdf', 'F');

        if ($model->load(Yii::$app->request->post())) {
            return $this->redirect(['send', 'id' => $model->id]);
        } else {
            return $this->render('_preview', [
                        'model' => $model,
                        'invoice' => $invoice,
                        'appointment' => $appointment,
                        'client_info' => $client_info,
                        'emails' => $emails,
                        'formLetters' => $formLetters,
            ]);
        }
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Show appointment on dashboard
     * Show details of appointment on dashboard
     * @param integer $id
     * @return mixed
     */
    public function actionDashboard($id) {
        $model = Appointment::findOne(['id' => $id, 'type' => 'work_order', 'status' => 'confirmed']);
        $client_info = ClientInfo::findOne($model->client_id);
        $properties = ArrayHelper::map($client_info->properties, 'id', 'name');
        $emails = ArrayHelper::map($client_info->mails, 'id', 'subject');
        $modelTask = $model->tasks;
        $duplicate = 0;

        if ($model->load(Yii::$app->request->post())) {
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validate($model)
                );
            }
            // validate all models
            $valid = $model->validate();
            if ($valid) {
                //convert date in mysql format
                $appointment = Yii::$app->request->post('Appointment');
                $model->start_time = date("H:i:s", strtotime($appointment['start_time']));
                $model->end_time = date("H:i:s", strtotime($appointment['end_time']));
                $model->save(false);
                Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment updated.'));
                return $this->redirect(['/dashboard']);
            } else {
                return $this->renderPartial('_dashboard', [
                            'model' => $model,
                            'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                            'client_info' => $client_info,
                            'properties' => $properties,
                            'duplicate' => $duplicate,
                            'emails' => $emails,
                ]);
            }
        }
        return $this->renderPartial('_dashboard', [
                    'model' => $model,
                    'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                    'client_info' => $client_info,
                    'properties' => $properties,
                    'duplicate' => $duplicate,
                    'emails' => $emails,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Deletes an existing Appointment model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();
         //Remove pdf file
        unlink(\Yii::$app->request->BaseUrl . 'uploads/estimates/estimate-' . $id . '.pdf');
        return $this->redirect(['index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Duplication an existing Appointment model.
     * If duplicate is successful, the browser will be redirected to the 'update' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDuplicate($id) {
        Yii::$app->session->set('duplicate', $id);
        Yii::$app->session->setFlash('success', Yii::t('app', 'Appointment duplicated.'));
        return $this->redirect(['create', 'id' => $id]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send a email to client.
     * If creation of appointment successful, the browser will be redirected to the '_send' page.
     * @return mixed
     */
    public function actionSend($id = null) {
        Yii::$app->session->remove('duplicate');
        $appointment = $this->findModel($id);
        $model = new Messages;
        $client_info = ClientInfo::findOne($appointment->client_id);
        $emails = ArrayHelper::map($client_info->clientEmails, 'client_email', 'name');
        $formLetters = ArrayHelper::map(FormLetters::find()->where(['type' => 'work_order', 'confirmed_unconfirmed' => 'confirmed', 'options' => 'gate'])->all(), 'id', 'name');
        if ($model->load(Yii::$app->request->post())) {
            return $this->redirect(['send', 'id' => $model->id]);
        } else {
            return $this->render('_send', [
                        'model' => $model,
                        'appointment' => $appointment,
                        'client_info' => $client_info,
                        'emails' => $emails,
                        'formLetters' => $formLetters,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send email to client.
     * If creation of appointment successful, the browser will be redirected to the '_send' page.
     * @return redirect to client page
     */
    public function actionSendEmail() {
        $data = Yii::$app->request->post();
        if($data['Messages']['appointment_id']){
            Yii::$app->mailer->compose('estimate', ['content' => $data['preview_data']])
                    ->setFrom(Yii::$app->params['fromEmail'])
                    ->setTo($data['Messages']['emails'])
                    ->setSubject(Yii::$app->name . ' Estimate')
                    ->attach('uploads/estimates/estimate-' . $data['Messages']['appointment_id'] . '.pdf')
                    ->send();
        }else{
            Yii::$app->mailer->compose('appointment', ['content' => $data['preview_data']])
              ->setFrom(Yii::$app->params['fromEmail'])
              ->setTo($data['Messages']['emails'])
              ->setSubject(Yii::$app->name . ' Appointment')
              ->send();
        }
        Yii::$app->session->setFlash('success', Yii::t('app', 'Email sent.'));
        Yii::$app->session->remove('duplicate');
        return $this->redirect(['/appointment/index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Show formletter to send appointment.
     * @return redirect to client page
     */
    public function actionFormletter() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
            $list = FormLetters::find()->where(['type' => $_POST['depdrop_parents'][0], 'confirmed_unconfirmed' => $_POST['depdrop_parents'][1], 'options' => $_POST['depdrop_parents'][2]])->asArray()->all();
            $selected = null;
            if ($_POST['depdrop_parents'][0] != null && count($list) > 0) {
                $selected = '';
                foreach ($list as $i => $account) {
                    $out[] = ['id' => $account['id'], 'name' => $account['name']];
                    if ($i == 0) {
                        $selected = $account['id'];
                    }
                }
                // Shows how you can preselect a value
                echo json_encode(['output' => $out, 'selected' => $selected]);
                return;
            }
        }
        echo json_encode(['output' => '', 'selected' => '']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the Appointment model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Appointment the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Appointment::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
