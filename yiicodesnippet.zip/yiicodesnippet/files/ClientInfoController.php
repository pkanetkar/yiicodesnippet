<?php

namespace app\controllers;

use Yii;
use app\models\ClientInfo;
use app\models\Mailbox;
use app\models\ClientInfoSearch;
use app\models\Appointment;
use app\models\Invoice;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\ClientEmails;
use app\models\ClientProperties;
use app\models\Model;
use yii\web\UploadedFile;
use yii\helpers\ArrayHelper;
use yii\imagine\Image;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * ClientInfoController implements the CRUD actions for ClientInfo model.
 */
class ClientInfoController extends Controller {

    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all ClientInfo models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new ClientInfoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $dataProvider->pagination->pageSize= Yii::$app->params['PAGINATION_SIZE'];
      
        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }
    
     /**
     * Lists all ClientInfo modal index.
     * @return mixed
     */
    public function actionModalIndex() {
        $searchModel = new ClientInfoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $dataProvider->pagination->pageSize= Yii::$app->params['PAGINATION_SIZE'];
        
        if (Yii::$app->request->isAjax) {
            $this->layout   = 'wrapper-black';
            return $this->renderAjax('modal-index', [
                'searchModel' => $searchModel,
                'dataProvider'=> $dataProvider,
            ]);
        } else {
        return $this->render('modal-index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
        }
    }
    

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single ClientInfo model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $email_count    = Yii::$app->db->createCommand('SELECT count(id) FROM mailbox where client_id='.$id)->queryScalar();
        $property_count = Yii::$app->db->createCommand('SELECT count(id) FROM client_properties where client_id='.$id)->queryScalar();
        $result = ClientEmails::find()
            ->select('client_email')
            ->limit(3)
	    ->where("client_id=".$id)
            ->asArray()
	    ->all();
     
        if (Yii::$app->request->isAjax) {
            $this->layout   = 'wrapper-black';
            return $this->render('view', [
                'model'          => $this->findModel($id),
                'email_count'    => $email_count,
                'property_count' => $property_count,
                'result'         => $result,
         ]);
        } else {
        return $this->render('view', [
                'model'         => $this->findModel($id),
                'email_count'   => $email_count,
                'property_count'=> $property_count,
                 'result'         => $result,
        ]);
        }
        
    }
    
    /**
     * Displays a single ClientInfo model.
     * @param integer $id
     * @return mixed
     */
    public function actionViewProperties($id) {
        $email_count    = Yii::$app->db->createCommand('SELECT count(id) FROM mailbox where client_id='.$id)->queryScalar();
        $property_count = Yii::$app->db->createCommand('SELECT count(id) FROM client_properties where client_id='.$id)->queryScalar();
        if (Yii::$app->request->isAjax) {
            $this->layout   = 'wrapper-black';
            return $this->render('view_properties', [
                'model'          => $this->findModel($id),
                'email_count'    => $email_count,
                'property_count' => $property_count,
         ]);
        } else {
        return $this->render('view_properties', [
                'model'         => $this->findModel($id),
                'email_count'   => $email_count,
                'property_count'=> $property_count,
        ]);
        }
        
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new ClientInfo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionCreate($id=NULL) {
        $model = new ClientInfo();
        $modelClientEmail = [new ClientEmails];
        $email = Mailbox::findOne($id);
        
        if ($model->load(Yii::$app->request->post())) {
            $modelClientEmail = Model::createMultiple(ClientEmails::classname());
            Model::loadMultiple($modelClientEmail, Yii::$app->request->post());

            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelClientEmail), ActiveForm::validate($model)
                );
            }
            //Upload image
             $img = UploadedFile::getInstance($model, 'photo');
                        if (empty($img)) {
                            $model->photo = 'no_Image.png';
                        } else {
                            $file_name = time().$img;
                            $model->photo = $file_name;
                        }
                        if (!empty($img)) {
                            $img->saveAs('uploads/client/' . $file_name);
                            Image::thumbnail('uploads/client/' . $file_name, 120, 120)
                            ->save(Yii::getAlias('uploads/client/thumb/' . $file_name), ['quality' => 80]);
                            $model->save();
                        }
            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelClientEmail) && $valid;

            if ($valid) {
                 
                $transaction = \Yii::$app->db->beginTransaction();
                
                try {
                   
                    if ($flag = $model->save(false)) {
                        foreach ($modelClientEmail as $modelClientEmail) {
                            
                            $modelClientEmail->client_id = $model->id;
                            if (!($flag = $modelClientEmail->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();                       
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Client created.'));
                        return $this->redirect(['view', 'id' => $model->id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }else {
                return $this->render('create', [
                            'model' => $model,
                            'email' => $email,
                            'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
                ]);
            }
        } else if (Yii::$app->request->isAjax) {
            return $this->renderAjax('create', [
               'model' => $model,
               'email' => $email,
               'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }else {
            return $this->render('create', [
                        'model' => $model,
                        'email' => $email,
                        'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }
    }
    
    /**
     * Creates a new ClientInfo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionModalCreate($id=NULL) {
        $model = new ClientInfo();
        $modelClientEmail = [new ClientEmails];
        $email = Mailbox::findOne($id);
        
        if ($model->load(Yii::$app->request->post())) {
            $modelClientEmail = Model::createMultiple(ClientEmails::classname());
            Model::loadMultiple($modelClientEmail, Yii::$app->request->post());

            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelClientEmail), ActiveForm::validate($model)
                );
            }
             $img = UploadedFile::getInstance($model, 'photo');
                        if (empty($img)) {
                            $model->photo = 'no_Image.png';
                        } else {
                            $file_name = time().$img;
                            $model->photo = $file_name;
                        }
                        if (!empty($img)) {
                            $img->saveAs('uploads/client/' . $file_name);
                            Image::thumbnail('uploads/client/' . $file_name, 120, 120)
                            ->save(Yii::getAlias('uploads/client/thumb/' . $file_name), ['quality' => 80]);
                            $model->save();
                        }
            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelClientEmail) && $valid;

            if ($valid) {
                 
                $transaction = \Yii::$app->db->beginTransaction();
                
                try {
                   
                    if ($flag = $model->save(false)) {
                        foreach ($modelClientEmail as $modelClientEmail) {
                            
                            $modelClientEmail->client_id = $model->id;
                            if (!($flag = $modelClientEmail->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();                       
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Client created.'));
                        return $this->redirect(['view', 'id' => $model->id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }else {
                return $this->render('create', [
                            'model' => $model,
                            'email' => $email,
                            'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
                ]);
            }
        } else if (Yii::$app->request->isAjax) {
            return $this->renderAjax('modal-create', [
               'model' => $model,
               'email' => $email,
               'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }else {
            return $this->render('modal-create', [
                        'model' => $model,
                        'email' => $email,
                        'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing ClientInfo model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $modelClientEmail = $model->clientEmails;
        $oldFileName = $model->photo;
        $email = [];
        
         if ($model->load(Yii::$app->request->post())) {
            $oldIDs = ArrayHelper::map($modelClientEmail, 'id', 'id');
            $modelClientEmail = Model::createMultiple(ClientEmails::classname(), $modelClientEmail);
            Model::loadMultiple($modelClientEmail, Yii::$app->request->post());
            $deletedIDs = array_diff($oldIDs, array_filter(ArrayHelper::map($modelClientEmail, 'id', 'id')));
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                    ActiveForm::validateMultiple($modelClientEmail), ActiveForm::validate($model)
                );
            }
            $img = UploadedFile::getInstance($model, 'photo');

            if (empty($img)) {
                $model->photo = $oldFileName;
            } else {
                $file_name = time().$img;
                $model->photo = $file_name;
            }
            if (!empty($img)) {
                $img->saveAs('uploads/client/' . $file_name);
                Image::thumbnail('uploads/client/' . $file_name, 120, 120)
                ->save(Yii::getAlias('uploads/client/thumb/' . $file_name), ['quality' => 80]);
                 $model->save();
            }
            // validate all models
           $valid = $model->validate();
           $valid = Model::validateMultiple($modelClientEmail) && $valid;
           
            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                
                try {
                    if ($flag = $model->save(false)) {
                        if (!empty($deletedIDs)) {
                            ClientEmails::deleteAll(['id' => $deletedIDs]);
                        }
                        foreach ($modelClientEmail as $modelClientEmail) {
                            $modelClientEmail->client_id = $model->id;
                            if (!($flag = $modelClientEmail->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                         Yii::$app->session->setFlash('success', Yii::t('app', 'Client is updated.'));
                        return $this->redirect(['view', 'id' => $id]);
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }
             else {
            return $this->render('update', [
                        'model' => $model,
                        'email' => $email,
                        'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }
        }else if (Yii::$app->request->isAjax) {
            return $this->renderAjax('update', [
                        'model' => $model,
                        'email' => $email,
                        'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }else {
            return $this->render('update', [
                        'model' => $model,
                        'email' => $email,
                        'modelClientEmail' => (empty($modelClientEmail)) ? [new ClientEmails] : $modelClientEmail,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Deletes an existing ClientInfo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
       
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', Yii::t('app', 'Client deleted.'));
        return $this->redirect(['index']);
    }
    
    /**
     * Deletes an existing ClientInfo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeleteClient($id) {
//       echo "here";exit;
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', Yii::t('app', 'Client deleted.'));
        return $this->redirect(['index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientInfo model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientInfo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = ClientInfo::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all client list for dropdown
     * @param string $q, $id
     * @return array $out
     */ 
    public function actionClientlist($q = null, $id = null) {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $connection = Yii::$app->db;
            $result = Yii::$app->db->createCommand('Select id,  CONCAT(last_name,", ",first_name ) AS text From client_info Where company like "%'.$q.'%" OR first_name like "%'.$q.'%" OR last_name like "%'.$q.'%"'.Yii::$app->params['DROPDOWN_SIZE'])->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => ClientInfo::find($id)->company];
        }
        return $out;
    }
     /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all client those has appointment
     * @param string $q, $id
     * @return array $out
     */ 
    public function actionClienthasappointment($q = null, $id = null) {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $connection = Yii::$app->db;
            $result = Yii::$app->db->createCommand('Select c.id,  CONCAT(c.first_name," ",c.last_name, "(", c.company ,")" ) AS text From client_info c right join appointment a on a.client_id = c.id Where company like "%'.$q.'%" OR first_name like "%'.$q.'%" OR last_name like "%'.$q.'%" GROUP BY c.id ')->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => ClientInfo::find($id)->company];
        }
        return $out;
    }
     /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all client those has invoice
     * @param string $q, $id
     * @return array
     */ 
    public function actionClienthasinvoice($q = null, $id = null) {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $connection = Yii::$app->db;
            $result = Yii::$app->db->createCommand('Select c.id,  CONCAT(c.first_name," ",c.last_name, "(", c.company ,")" ) AS text From client_info c right join invoice a on a.client_id = c.id Where company like "%'.$q.'%" OR first_name like "%'.$q.'%" OR last_name like "%'.$q.'%" GROUP BY c.id ')->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => ClientInfo::find($id)->company];
        }
        return $out;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all appointment of search values
     * @param string $q, $id
     * @return array
     */ 
    public function actionAppointmentlist($q = null, $id = null) {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $result = Yii::$app->db->createCommand('Select id , id AS text From appointment Where id like "%'.$q.'%" AND client_id='.$id)->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => ClientInfo::find($id)->company];
        }
        return $out;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all appointment of search values
     * @param string $q, $id
     * @return array
     */ 
    public function actionInvoicelist($q = null, $id = null) {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $out = ['results' => ['id' => '', 'text' => '']];
        if (!is_null($q)) {
            $connection = Yii::$app->db;
            $result = Yii::$app->db->createCommand('Select id , id AS text From invoice Where id like "%'.$q.'%" AND client_id='.$id)->queryAll();
            $out['results'] = array_values($result);
        } elseif ($id > 0) {
            $out['results'] = ['id' => $id, 'text' => ClientInfo::find($id)->company];
        }
        return $out;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all properties of client
     * @param string $q, $id
     * @return json
     */ 
    public function actionProperties() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
            $id = end($_POST['depdrop_parents']);
            $list = ClientProperties::find()->andWhere(['client_id'=>$id])->asArray()->all();
            $selected  = null;
            if ($id != null && count($list) > 0) {
                $selected = '';
                foreach ($list as $i => $account) {
                    $out[] = ['id' => $account['id'], 'name' => $account['name']];
                    if ($i == 0) {
                        $selected = $account['id'];
                    }
                }
                // Shows how you can preselect a value
                echo json_encode(['output' => $out, 'selected'=>$selected]);
                return;
            }
        }
        echo json_encode(['output' => '', 'selected'=>'']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all appointment 
     * @param string $q, $id
     * @return json
     */ 
    public function actionAppointment() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
            $id = end($_POST['depdrop_parents']);
            $list = Appointment::find()->andWhere(['client_id'=>$id,'type'=>'work_order','status'=>'confirmed'])->asArray()->all();
            $selected  = null;
            if ($id != null && count($list) > 0) {
                $selected = '';
                foreach ($list as $i => $account) {
                    $out[] = ['id' => $account['id'], 'name' => $account['title'].'('.$account['id'].')'];
                    if ($i == 0) {
                        $selected = $account['id'];
                    }
                }
                // Shows how you can preselect a value
                echo json_encode(['output' => $out, 'selected'=>$selected]);
                return;
            }
        }
        echo json_encode(['output' => '', 'selected'=>'']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * List of all appointment 
     * @param string $q, $id
     * @return json
     */ 
    public function actionInvoice() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
            $id = end($_POST['depdrop_parents']);
            $list = Invoice::find()->andWhere(['client_id'=>$id])->andWhere(['>','payment_due',0])->asArray()->all();
            $selected  = null;
            if ($id != null && count($list) > 0) {
                $selected = '';
                foreach ($list as $i => $account) {
                    $out[] = ['id' => $account['id'], 'name' => $account['id']];
                    if ($i == 0) {
                        $selected = $account['id'];
                    }
                }
                // Shows how you can preselect a value
                echo json_encode(['output' => $out, 'selected'=>$selected]);
                return;
            }
        }
        echo json_encode(['output' => '', 'selected'=>'']);
    }
    public function actionEmails() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
            $id = end($_POST['depdrop_parents']);
            $list = Mailbox::find()->where(['client_id'=>$id])->orderBy(['mailbox_date'=> SORT_DESC])->asArray()->all();
            $selected  = null;
            if ($id != null && count($list) > 0) {
                $selected = '';
                foreach ($list as $i => $account) {
                    $out[] = ['id' => $account['id'], 'name' => $account['subject']];
                    if ($i == 0) {
                        $selected = $account['id'];
                    }
                }
                // Shows how you can preselect a value
                echo json_encode(['output' => $out, 'selected'=>$selected]);
                return;
            }
        }
        echo json_encode(['output' => '', 'selected'=>'']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientProperties model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @return Clientinfo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionGetInfo() {
        $id = Yii::$app->request->post('id');
        if (( $model = $this->findModel($id)) !== null) {
             $model->city = ($model->cityInfo =='')?'':$model->cityInfo->city ;
             $model->postal_code = ($model->postal_code ==null)?'':$model->postal_code ;
            Yii::$app->response->format = Response::FORMAT_JSON;
            return  $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
        
    }

}
