<?php

namespace app\controllers;

use Yii;
use app\models\ClientProperties;
use app\models\ClientPropertiesSearch;
use app\models\ClientPropertyEmails;
use app\models\Model;
use yii\web\UploadedFile;
use yii\helpers\ArrayHelper;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use app\models\ClientPropertyImages;
use yii\imagine\Image;
use yii\widgets\ActiveForm;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * ClientPropertiesController implements the CRUD actions for ClientProperties model.
 */
class ClientPropertiesController extends Controller {

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all ClientProperties models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new ClientPropertiesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }
    
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all ClientProperties models.
     * @return mixed
     */
    public function actionModalIndex() {
        $searchModel = new ClientPropertiesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $dataProvider->pagination->pageSize= Yii::$app->params['PAGINATION_SIZE'];

       if (Yii::$app->request->isAjax) {
            $this->layout   = 'wrapper-black';
            return $this->renderAjax('modal-index', [
                'searchModel' => $searchModel,
                'dataProvider'=> $dataProvider,
            ]);
        } else {
        return $this->render('modal-index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
        }
    }
   

     /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single ClientProperties model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $email_count    = Yii::$app->db->createCommand('SELECT count(id) FROM mailbox where client_id='.$id)->queryScalar();
        $property_count = Yii::$app->db->createCommand('SELECT count(id) FROM client_properties where client_id='.$id)->queryScalar();
        $property_img = \app\models\ClientPropertyImages::find()->where(['p_id' => $id])->asArray()->all();
        $model = $this->findModel($id);
        
        $client_info = \app\models\ClientInfo::find()->where(['id' => $model->client_id])->asArray()->all();
        if (Yii::$app->request->isAjax) {
            $this->layout   = 'wrapper-black';
            return $this->render('view', [
                'model'          => $this->findModel($id),
                'property_img'   => $property_img,
                'email_count'    => $email_count,
                'property_count' => $property_count,
                'client_info'    => $client_info,
         ]);
        } else {
        return $this->render('view', [
                'model'         => $this->findModel($id),
                'property_img' => $property_img,
                'email_count'   => $email_count,
                'property_count'=> $property_count,
                'client_info'    => $client_info,
        ]);
        }
        
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new ClientProperties model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * $param integer $id
     * @return mixed
     */
    public function actionCreate($id=NULL) {
        $model = new ClientProperties();
        $modelPropertyEmail = [new ClientPropertyEmails];
        if($id){
             $model->client_id = $id;
        }
        $modelPopertyImages = new ClientPropertyImages();

        if ($model->load(Yii::$app->request->post())) {

            
            $modelPropertyEmail = Model::createMultiple(ClientPropertyEmails::classname());
            Model::loadMultiple($modelPropertyEmail, Yii::$app->request->post());
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelPropertyEmail), ActiveForm::validate($model)
                );
            }
            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelPropertyEmail) && $valid;
            
            $get_city_id = Yii::$app->db->createCommand('SELECT UCASE(city),id FROM location where city=UCASE("'.$model->city.'") and state="'.$model->state.'"')->queryAll();
            for($i=0;$i<sizeof($get_city_id);$i++)
            {
                $city_id= $get_city_id[$i]['id'];
            }
          
            if ($valid) {
                 
                $transaction = \Yii::$app->db->beginTransaction();
                
                try {
                    $model->city = $city_id;
                    if ($flag = $model->save(false)) {
                        foreach ($modelPropertyEmail as $modelPropertyEmail) {
                            
                            $modelPropertyEmail->p_id = $model->id;
                            $modelPropertyEmail->client_id = $model->client_id;
                            if (!($flag = $modelPropertyEmail->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();      
                         $modelPopertyImages->property_img = UploadedFile::getInstances($modelPopertyImages, 'photo_img');

                            foreach ($modelPopertyImages->property_img as $image) {

                                $modelPopertyImages1 = new \app\models\ClientPropertyImages();
                                $file_name = time().$image->name;
                                $image->saveAs("uploads/properties/".$file_name);
                                //Create thumbnail
                                 Image::thumbnail('uploads/properties/'.$file_name, 120, 120)
                                ->save(Yii::getAlias('uploads/properties/thumb/'.$file_name), ['quality' => 80]);
                                $modelPopertyImages1->property_img =$file_name;
                                $modelPopertyImages1->p_id = $model->id;

                                $modelPopertyImages1->save(false);
                            }
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Client property created.'));
                        if($id){
                                return $this->redirect(['/client-info/view?id=' . $id]);
                            }else{
                                return $this->redirect(['/client-properties/index']);
                            }
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }else {
                return $this->render('create', [
                            'model' => $model,
                            'id' => $id,
                            'modelPopertyImages' => $modelPopertyImages,
                            'modelPropertyEmail' => (empty($modelPropertyEmail)) ? [new ClientPropertyEmails] : $modelPropertyEmail,
                ]);
            }            
        } else {

            return $this->render('create', [
                        'model' => $model,
                        'id' => $id,
                        'modelPopertyImages' => $modelPopertyImages,
                        'modelPropertyEmail' => (empty($modelPropertyEmail)) ? [new ClientPropertyEmails] : $modelPropertyEmail,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing ClientProperties model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {

        $model = $this->findModel($id);
        $modelPropertyEmail = $model->propertyEmails;
        $modelPopertyImages = new ClientPropertyImages();
        if ($model->load(Yii::$app->request->post())) {
            
            $oldIDs = ArrayHelper::map($modelPropertyEmail, 'p_id', 'id');
            $modelPropertyEmail = Model::createMultiple(ClientPropertyEmails::classname(), $modelPropertyEmail);
            Model::loadMultiple($modelPropertyEmail, Yii::$app->request->post());
            $deletedIDs = array_diff($oldIDs, array_filter(ArrayHelper::map($modelPropertyEmail, 'p_id', 'id')));
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                    ActiveForm::validateMultiple($modelPropertyEmail), ActiveForm::validate($model)
                );
            }
            
            $modelPopertyImages->property_img = UploadedFile::getInstances($modelPopertyImages, 'photo_img');

            foreach ($modelPopertyImages->property_img as $image) {

                $modelPopertyImages1 = new ClientPropertyImages();
                $file_name = time().$image->name;
                $image->saveAs("uploads/properties/".$file_name);
                //Create thumbnail
                 Image::thumbnail('uploads/properties/'.$file_name, 120, 120)
                ->save(Yii::getAlias('uploads/properties/thumb/'.$file_name), ['quality' => 80]);
                $modelPopertyImages1->property_img =($file_name)?$file_name:'no_Image.png';
                $modelPopertyImages1->p_id = $model->id;

                $modelPopertyImages1->save(false);
            }
            
            // validate all models
           $valid = $model->validate();
           $valid = Model::validateMultiple($modelPropertyEmail) && $valid;
           
           $get_city_id = Yii::$app->db->createCommand('SELECT UCASE(city),id FROM location where city=UCASE("'.$model->city.'") and state="'.$model->state.'"')->queryAll();
           
           for($i=0;$i<sizeof($get_city_id);$i++)
           {
               $city_id= $get_city_id[$i]['id'];
           }
        
            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    $model->city = $city_id;
                    if ($flag = $model->save(false)) {
                        if (!empty($deletedIDs)) {
                            \app\models\ClientEmails::deleteAll(['id' => $deletedIDs]);
                        }
                        foreach ($modelPropertyEmail as $modelPropertyEmail) {
                            $modelPropertyEmail->p_id = $model->id;
                            $modelPropertyEmail->client_id = $model->client_id;
                            if (!($flag = $modelPropertyEmail->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        Yii::$app->session->setFlash('success', Yii::t('app', 'Client property updated.'));
                        if($id){
                            return $this->redirect(['/client-info/view','id'=>$model->client_id]);
                        }else{
                                return $this->redirect(['/client-properties/index']);
                        }
                        
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            }
             else {
            
            $prop_img = ClientPropertyImages::find()->where(['p_id' => $id])->asArray()->all();
            return $this->render('update', [
                        'model' => $model,
                        'modelPropertyEmail' => (empty($modelPropertyEmail)) ? [new ClientPropertyEmails] : $modelPropertyEmail,
                        'modelPopertyImages' => $modelPopertyImages,
                        'id' => $id,
                        'prop_img' => $prop_img,
            ]);
        }
        } else {

            $prop_img = ClientPropertyImages::find()->where(['p_id' => $id])->asArray()->all();
            return $this->render('update', [
                        'model' => $model,
                        'modelPropertyEmail' => (empty($modelPropertyEmail)) ? [new ClientPropertyEmails] : $modelPropertyEmail,
                        'modelPopertyImages' => $modelPopertyImages,
                        'id' => $id,
                        'prop_img' => $prop_img,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Deletes an existing ClientProperties model.
     * If deletion is successful, the browser will be redirected to the 'client info' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        
        $model = $this->findModel($id);
        
        Yii::$app->session->setFlash('success', Yii::t('app', 'Client property deleted.'));
        $model->delete();
        //return $this->redirect(['client-info/view', 'id'=>$model->client_id]);
        return $this->redirect(['/client-properties/index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientProperties model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientProperties the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = ClientProperties::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientProperties model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientProperties the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionGetInfo() {
        $id = Yii::$app->request->post('id');
        if (( $model = $this->findModel($id)) !== null) {
            if($model->cityInfo){
                $model->city =$model->cityInfo->city;
            }     
            $data = new \stdClass();              
            if($model->address!='' && $model->city !='' && $model->state!='' && $model->pincode!=''){
                 $data->property = $model; 
                 $data->name=  $model->clientInfo->first_name.' '.$model->clientInfo->last_name;
            } 
            Yii::$app->response->format = Response::FORMAT_JSON;
            return  $data;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
