<?php

namespace app\controllers;

use Yii;
use app\models\Mailbox;
use app\models\ClientEmails;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * MailboxController implements the CRUD actions for Mailbox model.
 */
class MailboxController extends Controller {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all Mailbox models.
     * @return mixed
     */
    public function actionIndex() {
        //Get all email list
        $model = Mailbox::find()->orderBy(['mailbox_date' => SORT_DESC])->all();
        foreach ($model as $email) {
            //check client exist or not update client accordingly.
            $client = ClientEmails::find()->select('client_id')->where(['client_email' => $email->fromAddress])->one();
            if ($client) {
                \Yii::$app->db->createCommand("UPDATE mailbox SET client_id=:client_id WHERE id=:id")
                        ->bindValue(':id', $email->id)
                        ->bindValue(':client_id', $client->client_id)
                        ->execute();
            }
        }
        return $this->render('index', [
                    'model' => $model,
        ]);
    }

    /**
     * Displays a single Mailbox model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Mailbox model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        SettingController::actionSetSetting();
        //Create imap class object
        $mailbox = new \PhpImap\Mailbox('{imap.gmail.com:993/imap/ssl/novalidate-cert}INBOX', Yii::$app->session->get('email_address'), Yii::$app->session->get('email_password'), __DIR__);
       // Read all messaged into an array:
        $mailsIds = $mailbox->searchMailbox('ALL');
        $mailInfo = (array) $mailbox->getMailsInfo($mailsIds);
        //Search last unseen mail
        $lastId = Mailbox::find()->max('mailbox_id');
        if (!$mailsIds) {
            Yii::$app->session->setFlash('success', Yii::t('app', 'Mailbox is empty.'));
            return $this->redirect('index');
        }
        $data1 = [];
        foreach ($mailsIds as $key => $value) {
            $mails = [];
            $data = [];
            if ($lastId=='') {
                $mails = (array) $mailbox->getMail($mailsIds[$key]);
                $data['seen'] = $mailInfo[$key]->seen;
                $data['mailbox_id'] = $mails['id'];
                $data['mailbox_date'] = $mails['date'];
                $data['subject'] = $mails['subject'];
                $data['fromName'] = $mails['fromName'];
                $data['fromAddress'] = $mails['fromAddress'];
                $data['textPlain'] = $mails['textPlain'];
                $data['textHtml'] = $mails['textHtml'];
                $client = ClientEmails::find()->select('client_id')->where(['client_email' => $mails['fromAddress']])->asArray()->one();

                if (!empty($client)) {
                    $data['client_id'] = $client['client_id'];
                } else {
                    $data['client_id'] = NULL;
                }
                //Store all data
                $data1[] = $data;
            } else {
                if ($mailInfo[$key]->seen === 0) {
                    $mails = (array) $mailbox->getMail($mailsIds[$key]);
                    $data['seen'] = $mailInfo[$key]->seen;
                    $data['mailbox_id'] = $mails['id'];
                    $data['mailbox_date'] = $mails['date'];
                    $data['subject'] = $mails['subject'];
                    $data['fromName'] = $mails['fromName'];
                    $data['fromAddress'] = $mails['fromAddress'];
                    $data['textPlain'] = $mails['textPlain'];
                    $data['textHtml'] = $mails['textHtml'];
                    $client = ClientEmails::find()->select('client_id')->where(['client_email' => $mails['fromAddress']])->asArray()->one();

                    if (!empty($client)) {
                        $data['client_id'] = $client['client_id'];
                    } else {
                        $data['client_id'] = NULL;
                    }
                    //Store all data
                    $data1[] = $data;
               }
            }
        }
        //insert data into database
        Yii::$app->db->createCommand()->batchInsert(
                Mailbox::tableName(), ['seen', 'mailbox_id', 'mailbox_date', 'subject',
            'fromName', 'fromAddress', 'textPlain','textHtml','client_id'], $data1
        )->execute();
        Yii::$app->session->setFlash('success', Yii::t('app', 'Mailbox is ready.'));
        return $this->redirect('/mailbox/index');
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing Mailbox model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * 
     * Deletes an existing Mailbox model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Mailbox model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Mailbox the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Mailbox::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * View Product
     * @param int $id vendor id
     * @return array $model
     *      
     */
    public function actionViewMail($id) {
        Yii::$app->db->createCommand()->update('mailbox', ['seen' => 1],'id = '.$id)->execute();
        //Get email data
        $mail = \app\models\Mailbox::find()->where(['id' => $id])->one();
        return $this->renderPartial('_view-mail', [
                    'mail' => $mail,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientProperties model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientProperties the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionGetInfo() {
        $id = Yii::$app->request->post('id');
        if (( $model = Mailbox::find()->where(['id' => $id])->orderBy(['mailbox_date'=> SORT_DESC])->one()) !== null) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
