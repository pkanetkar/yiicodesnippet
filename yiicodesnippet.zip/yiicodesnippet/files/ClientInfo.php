<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "client_info".
 *
 * @property integer $id
 * @property string $company
 * @property string $first_name
 * @property integer $last_name
 * @property string $address1
 * @property string $address2
 * @property integer $city
 * @property string $state
 * @property integer $postal_code
 * @property integer $kids
 * @property string $gate_code
 * @property string $reference
 * @property string $phone_no1
 * @property string $phone_no2
 * @property string $client_desc
 * @property string $residence
 * @property string $mail_list
 * @property string $notes
 */
class ClientInfo extends \yii\db\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function tableName() {
        return 'client_info';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['first_name', 'last_name','reference', 'phone_no1'], 'required'], //'address1',
            [['postal_code', 'state','city','kids', 'gate_code', 'phone_no2','client_desc','mail_list', 'photo','phone_no3','notes'], 'safe'], //'residence','address2', 
            [['city', 'postal_code'], 'integer'],
            [['photo'], 'file', 'extensions' => 'png, jpg,jpeg'],
            ['phone_no1','checkMobile'],
            [['client_desc','mail_list', 'kids'], 'string'], //'residence','address1','address2', 
            [['company', 'last_name', 'first_name','reference', 'phone_no1', 'phone_no2','state','phone_no3'], 'string', 'max' => 35], 
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id' => 'ID',
            'company' => 'Company',
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'city' => 'City',
            'state' => 'State',
            'kids' => 'Kids',
            'reference' => 'Reference',
            'phone_no1' => 'Mobile1',
            'phone_no2' => 'Mobile2',
             'phone_no3' => 'Mobile3',
            'client_desc' => 'Client Desc',
            'mail_list' => 'Mail List',
            'email' => 'Email',
            'fullName' =>'Full Name',
            'combineName' =>'Full Name',
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Get user full name
     * @return full name
     */
    public function getDisplayName() {
        return $this->first_name . '-' . $this->last_name;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Check mobile validation
     * @return error
     */
    public function checkMobile(){
   
        if(!preg_match('/^\d{10}$/',preg_replace("/[^0-9]/", "", $this->phone_no1))){ 
           
               $this->addError('phone_no1', 'Mobile format does not match');  
        }
        if(!empty($this->phone_no2)){
            if(!preg_match('/^\d{10}$/',preg_replace("/[^0-9]/", "", $this->phone_no2))){ 

                   $this->addError('phone_no2', 'Mobile number must be of 10 digits.');  
            }        
        }
         if(!empty($this->phone_no3)){
            if(!preg_match('/^\d{10}$/',preg_replace("/[^0-9]/", "", $this->phone_no3))){ 

                   $this->addError('phone_no3', 'Mobile number must be of 10 digits.');  
            }        
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Cleint_email model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClientEmails() {
        return $this->hasMany(ClientEmails::className(), ['client_id' => 'id']);
    }
    
   
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Cleint_properties model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProperties() {
        return $this->hasMany(ClientProperties::className(), ['client_id' => 'id']);
    }
    
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with appointment model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAppointments() {
        return $this->hasMany(Appointment::className(), ['client_id' => 'id']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with appointment model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getInvoices() {
        return $this->hasMany(Invoice::className(), ['client_id' => 'id']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with location model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCityInfo() {
        return $this->hasOne(Location::className(), ['id' => 'city']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with appointment model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMail() {
        return $this->hasOne(Mailbox::className(), ['client_id' => 'id']);
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with appointment model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMails() {
        return $this->hasMany(Mailbox::className(), ['client_id' => 'id']);
    }
    
    public function getFullName() {
        return $this->last_name . ', ' . $this->first_name;
    }
    public function getCombineName() {
        return $this->first_name . ' ' . $this->last_name;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Cleint_email model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClientEmail() {
        return $this->hasOne(ClientEmails::className(), ['client_id' => 'id']);
    }

}
