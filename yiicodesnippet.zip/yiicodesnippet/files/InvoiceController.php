<?php

namespace app\controllers;

use Yii;
use app\models\Invoice;
use app\models\Appointment;
use app\models\AppointmentTasks;
use app\models\InvoiceSearch;
use app\models\ClientEmails;
use app\models\ClientPropertyEmails;
use app\models\InvoiceTasks;
use app\models\InvoiceEmails;
use app\models\Model;
use app\models\Messages;
use app\models\FormLetters;
use app\models\ClientInfo;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\widgets\ActiveForm;
use yii\web\Response;
use yii\helpers\ArrayHelper;
use mPDF;

/**
 * @author Santosh Kunjir <s.kunjir@splendornet.com>
 * InvoiceController implements the CRUD actions for Invoice model.
 */
class InvoiceController extends Controller {

    /**
     * @inheritdoc
     */
    public function beforeAction($action) {
        if ($action->id == 'send-email') {
            $this->enableCsrfValidation = false;
        }

        return parent::beforeAction($action);
    }

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Lists all Invoice models.
     * @return mixed
     */
    public function actionIndex() {
        $searchModel = new InvoiceSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Displays a single Invoice model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Creates a new Invoice model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($id = null, $client = null) {
        $client_info = [];
        if ($id) {
            $model = new Invoice();
            $modelInvoiceEmails = [new InvoiceEmails];
            $modelAppointment = Appointment::findOne($id);
            $modelTask = $modelAppointment->tasks;
            $client_info = ClientInfo::findOne($modelAppointment->client_id);
            $appointment = array('' => 'Select for an Appointment ID...') +
                    ArrayHelper::map(Appointment::getInvoiceAppointment($modelAppointment->client_id), 'id', function($model, $defaultValue) {
                        return $model['title'] . ' ( ' . $model['id'] . ' )';
                    }
            );
            $emails = $this->actionGetEmail($modelAppointment->client_id);
        } else if ($client) {
            $model = new Invoice();
            $modelInvoiceEmails = [new InvoiceEmails];
            $modelAppointment = new Appointment;
            $modelTask = [new AppointmentTasks];
            $client_info = ClientInfo::findOne($client);
            $appointment = array('' => 'Select for an Appointment ID...') +
                    ArrayHelper::map(Appointment::getInvoiceAppointment($modelAppointment->client_id), 'id', function($model, $defaultValue) {
                        return $model['title'] . ' ( ' . $model['id'] . ' )';
                    }
            );
            $emails = $this->actionGetEmail($client_info->id);
        } else {
            $model = new Invoice();
            $modelInvoiceEmails = [new InvoiceEmails];
            $modelAppointment = new Appointment;
            $modelTask = [new AppointmentTasks];
            $appointment = [];
            $client_info = [];
            $emails = [];
        }

        if ($model->load(Yii::$app->request->post())) {
            $modelInvoiceTask = Model::createMultiple(InvoiceTasks::classname());
            $modelInvoiceEmails = Model::createMultiple(InvoiceEmails::classname());
            Model::loadMultiple($modelInvoiceTask, Yii::$app->request->post());
            Model::loadMultiple($modelInvoiceEmails, Yii::$app->request->post());
            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelInvoiceTask), ActiveForm::validateMultiple($modelInvoiceEmails), ActiveForm::validate($model)
                );
            }
            // validate all models
            $valid = $model->validate();
            $valid = Model::validateMultiple($modelInvoiceTask) && $valid && Model::validateMultiple($modelInvoiceEmails);

            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                $model->payment_due = $model->amount;
                $i = 0;
                try {
                    if ($flag = $model->save(false)) {
                        foreach (Yii::$app->request->post('AppointmentTasks') as $models) {
                            $clone = new InvoiceTasks;
                            $clone->attributes = $models;
                            $clone->invoice_id = $model->id;
                            $clone->price = $models['price'];
                            $clone->taxable = $models['taxable'];
                            $clone->amount = $models['amount'];
                            $clone->service_id = $models['service_id'];
                            if (!($flag = $clone->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        foreach ($modelInvoiceEmails as $modelInvoiceEmails) {
                            $modelInvoiceEmails->invoice_id = $model->id;
                            $modelInvoiceEmails->client_id = $model->client_id;
                            if (!($flag = $modelInvoiceEmails->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        if (Yii::$app->request->post('btn_submit') === 'save') {
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice created.Invoice ID: ' . $model->id));
                            return $this->redirect(['index']);
                        } else {
                            return $this->redirect(['preview', 'id' => $model->id]);
                        }
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            } else {
                return $this->render('create', [
                            'model' => $model,
                            'client' => $client,
                            'emails' => $emails,
                            'client_info' => $client_info,
                            'appointment' => $appointment,
                            'modelAppointment' => $modelAppointment,
                            'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                            'modelInvoiceEmails' => (empty($modelInvoiceEmails)) ? [new InvoiceEmails] : $modelInvoiceEmails,
                ]);
            }
        } else {
            return $this->render('create', [
                        'model' => $model,
                        'client' => $client,
                        'emails' => $emails,
                        'client_info' => $client_info,
                        'appointment' => $appointment,
                        'modelAppointment' => $modelAppointment,
                        'modelTask' => (empty($modelTask)) ? [new AppointmentTasks] : $modelTask,
                        'modelInvoiceEmails' => (empty($modelInvoiceEmails)) ? [new InvoiceEmails] : $modelInvoiceEmails,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Get email list of client
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionGetEmail($client_id) {
        $emails['Emails'] = ArrayHelper::map(ClientEmails::find()->select(["client_email"])->where(['client_id' => $client_id])->asArray()->all(), 'client_email', 'client_email');
        $emails['Property emails'] = ArrayHelper::map(ClientPropertyEmails::find()->select(["email"])->where(['client_id' => $client_id])->asArray()->all(), 'email', 'email');
        return $emails;
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Updates an existing Invoice model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $modelTask = $model->tasks;
        $modelInvoiceEmails = $model->emails;
        $modelAppointment = Appointment::findOne($model->appointment_id);
        $emails = $this->actionGetEmail($modelAppointment->client_id);
        $client = '';
        $client_info = ClientInfo::findOne($modelAppointment->client_id);
        $appointment = ArrayHelper::map(Appointment::getInvoiceAppointment($modelAppointment->client_id), 'id', function($model, $defaultValue) {
                    return $model['title'] . ' ( ' . $model['id'] . ' )';
                });
        if ($model->load(Yii::$app->request->post())) {
            //Invoice Task list 
            $oldIDs = ArrayHelper::map($modelTask, 'id', 'id');
            $modelTask = Model::createMultiple(InvoiceTasks::classname(), $modelTask);
            Model::loadMultiple($modelTask, Yii::$app->request->post());
            $deletedIDs = array_diff($oldIDs, array_filter(ArrayHelper::map($modelTask, 'id', 'id')));

            //Invoice email list 
            $oldEmailIDs = ArrayHelper::map($modelInvoiceEmails, 'id', 'id');
            $modelInvoiceEmails = Model::createMultiple(InvoiceEmails::classname(), $modelInvoiceEmails);
            Model::loadMultiple($modelInvoiceEmails, Yii::$app->request->post());
            $deletedEmailIDs = array_diff($oldEmailIDs, array_filter(ArrayHelper::map($modelInvoiceEmails, 'id', 'id')));

            // ajax validation
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                return ArrayHelper::merge(
                                ActiveForm::validateMultiple($modelTask), ActiveForm::validate($model), ActiveForm::validateMultiple($modelInvoiceEmails)
                );
            }

            // validate all models
            $valid = $model->validate();
            $valid = (Model::validateMultiple($modelTask)) && ($valid);
            $valid = $valid && (Model::validateMultiple($modelInvoiceEmails));
            if ($valid) {
                $transaction = \Yii::$app->db->beginTransaction();
                try {
                    if ($flag = $model->save(false)) {
                        //Check invoice task id
                        if (!empty($deletedIDs)) {
                            InvoiceTasks::deleteAll(['id' => $deletedIDs]);
                        }
                        //Check invoice email id
                        if (!empty($deletedEmailIDs)) {
                            InvoiceEmails::deleteAll(['id' => $deletedEmailIDs]);
                        }
                        //save invoice email id
                        foreach ($modelInvoiceEmails as $modelInvoiceEmails) {
                            $modelInvoiceEmails->invoice_id = $model->id;
                            $modelInvoiceEmails->client_id = $model->client_id;
                            if (!($flag = $modelInvoiceEmails->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                        //save invocie task
                        foreach ($modelTask as $modelTask) {
                            $tmp[] = $modelTask;

                            $modelTask->invoice_id = $model->id;
                            if (!($flag = $modelTask->save(false))) {
                                $transaction->rollBack();
                                break;
                            }
                        }
                    }
                    if ($flag) {
                        $transaction->commit();
                        if (Yii::$app->request->post('btn_submit') === 'save') {
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice created.'));
                            return $this->redirect(['index']);
                        } else if (Yii::$app->request->post('btn_submit') === 'update') {
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice updated.'));
                            return $this->redirect(['index']);
                        } else if (Yii::$app->request->get('preview')) {
                            return $this->redirect(['preview', 'id' => $model->id]);
                        } else if (Yii::$app->request->post('btn_submit') === 'preview') {
                            return $this->redirect(['preview', 'id' => $model->id]);
                        } else {
                            Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice updated.'));
                            return $this->redirect(['index']);
                        }
                    }
                } catch (Exception $e) {
                    $transaction->rollBack();
                }
            } else {
                return $this->render('update', [
                            'model' => $model,
                            'emails' => $emails,
                            'appointment' => $appointment,
                            'client' => $client,
                            'client_info' => $client_info,
                            'modelAppointment' => $modelAppointment,
                            'modelTask' => (empty($modelTask)) ? [new InvoiceTasks] : $modelTask,
                            'modelInvoiceEmails' => (empty($modelInvoiceEmails)) ? [new InvoiceEmails] : $modelInvoiceEmails,
                ]);
            }
        } else {
            return $this->render('update', [
                        'model' => $model,
                        'emails' => $emails,
                        'appointment' => $appointment,
                        'client' => $client,
                        'client_info' => $client_info,
                        'modelAppointment' => $modelAppointment,
                        'modelTask' => (empty($modelTask)) ? [new InvoiceTasks] : $modelTask,
                        'modelInvoiceEmails' => (empty($modelInvoiceEmails)) ? [new InvoiceEmails] : $modelInvoiceEmails,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send a email to client.
     * If creation of appointment successful, the browser will be redirected to the '_send' page.
     * @return mixed
     */
    public function actionSend($id = null) {
        $invoice = $this->findModel($id);
        $appointment = $invoice->appointment;
        $model = new Messages;
        $client_info = ClientInfo::findOne($invoice->client_id);
        $emails = ArrayHelper::map($client_info->clientEmails, 'client_email', 'name');
        $formLetters = ArrayHelper::map(FormLetters::find()->all(), 'id', 'name');
        // get your HTML raw content without any layouts or scripts
        $mpdf = new mPDF();
        $stylesheet = file_get_contents('css/style.css');
        $stylesheet .= file_get_contents('css/print.css');

        $mpdf->WriteHTML($stylesheet, 1);

        $mpdf->WriteHTML($this->renderPartial('_pdf', ['model' => $model,
                    'invoice' => $invoice,
                    'client_info' => $client_info,
                    'appointment' => $appointment,
                    'formLetters' => $formLetters]), 2);
        $mpdf->Output(\Yii::$app->request->BaseUrl . 'uploads/invoices/invoice-' . $id . '.pdf', 'F');

        if ($model->load(Yii::$app->request->post())) {
            return $this->redirect(['send', 'id' => $model->id]);
        } else {
            return $this->render('_send', [
                        'model' => $model,
                        'invoice' => $invoice,
                        'appointment' => $appointment,
                        'client_info' => $client_info,
                        'emails' => $emails,
                        'formLetters' => $formLetters,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send a email to client.
     * If creation of appointment successful, the browser will be redirected to the '_send' page.
     * @return mixed
     */
    public function actionEmail($id = null) {
        $invoice = $this->findModel($id);
        $modelInvoiceEmails = $invoice->emails;

        $client_info = ClientInfo::findOne($invoice->client_id);
        return $this->renderPartial('_email', [
                    'invoice' => $invoice,
                    'modelInvoiceEmails' => $modelInvoiceEmails,
                    'client_info' => $client_info,
        ]);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send a email to client.
     * If creation of invoice successful, the browser will be redirected to the '_send' page.
     * @return mixed
     */
    public function actionPreview($id = null) {
        SettingController::actionSetSetting();
        $invoice = $this->findModel($id);
        $appointment = $invoice->appointment;
        $modelInvoiceEmails = $invoice->emails;
        $model = new Messages;
        $client_info = ClientInfo::findOne($invoice->client_id);
        $emails = ArrayHelper::map($client_info->clientEmails, 'client_email', 'name');
        $formLetters = ArrayHelper::map(FormLetters::find()->all(), 'id', 'name');
        // get your HTML raw content without any layouts or scripts
        $mpdf = new mPDF();
        $stylesheet = file_get_contents('css/style.css');
        $mpdf->WriteHTML($stylesheet, 1);
        $mpdf->WriteHTML($this->renderPartial('_pdf', ['model' => $model,
                    'invoice' => $invoice,
                    'client_info' => $client_info,
                    'appointment' => $appointment,
                    'formLetters' => $formLetters]), 2);

        $mpdf->Output(\Yii::$app->request->BaseUrl . 'uploads/invoices/invoice-' . $id . '.pdf', 'F');

        if ($model->load(Yii::$app->request->post())) {
            return $this->redirect(['send', 'id' => $model->id]);
        } else {
            return $this->render('_preview', [
                        'model' => $model,
                        'invoice' => $invoice,
                        'modelInvoiceEmails' => (empty($modelInvoiceEmails)) ? [new InvoiceEmails] : $modelInvoiceEmails,
                        'appointment' => $appointment,
                        'client_info' => $client_info,
                        'emails' => $emails,
                        'formLetters' => $formLetters,
            ]);
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Send email to client.
     * If creation of invoice successful, the browser will be redirected to the '_send' page.
     * @return redirect to client page
     */
    public function actionSendEmail() {
        $invoice = $this->findModel(Yii::$app->request->post('invoice-id'));
        $appointment = $invoice->appointment;
        $modelInvoiceEmails = $invoice->emails;
        $to = [];
        $cc = [];
        $bcc = [];
        foreach ($modelInvoiceEmails as $mail) {
            if ($mail['type'] == 'main') {
                $to[] = $mail['email'];
            } else if ($mail['type'] == 'cc') {
                $cc[] = $mail['email'];
            } else if ($mail['type'] == 'bcc') {
                $bcc[] = $mail['email'];
            }
        }
        $data = Yii::$app->request->post();
        Yii::$app->mailer->compose('invoice', ['content' => $data['message']])
                ->setFrom(Yii::$app->params['fromEmail'])
                ->setTo($to)
                ->setCc($cc)
                ->setBcc($bcc)
                ->setSubject(Yii::$app->name . ' Invoice')
                ->attach('uploads/invoices/invoice-' . $data['invoice-id'] . '.pdf')
                ->send();
        Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice sent.'));
        return $this->redirect(['/invoice/index']);
    }

    /**
     * Deletes an existing Invoice model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        //delete invoice
        $this->findModel($id)->delete();
        //Remove invoice emails
        InvoiceEmails::deleteAll(['invoice_id' => $id]);
        //REmove invoice tasks
        InvoiceTasks::deleteAll(['invoice_id' => $id]);
        //Remove pdf file
        unlink(\Yii::$app->request->BaseUrl . 'uploads/invoices/invoice-' . $id . '.pdf');
        Yii::$app->session->setFlash('success', Yii::t('app', 'Invoice deleted.'));
        return $this->redirect(['index']);
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the Invoice model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Invoice the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Invoice::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Finds the ClientProperties model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ClientProperties the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionGetInfo() {
        $id = Yii::$app->request->post('id');
        if (( $model = $this->findModel($id)) !== null) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
