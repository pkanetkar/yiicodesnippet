<?php

namespace app\models;
use nepstor\validators\DateTimeCompareValidator;
use Yii;

/**
 * This is the model class for table "appointment".
 *
 * @property integer $id
 * @property integer $client_id
 * @property string $status
 * @property string $appointment_date
 * @property string $start_time
 * @property string $end_time
 * @property string $description
 * @property integer $worksite
 * @property integer $billing
 * @property string $create_at
 * @property string $updated_at
 * @property integer $created_by
 */
class Appointment extends \yii\db\ActiveRecord
{
    public $email_text;
   // public $email;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'appointment';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['client_id', 'appointment_date', 'start_time', 'billing', 'end_time','status','type','title','property_id'], 'required'],
            [['status','worksite', 'billing','description','type','title'], 'string'],
            [['appointment_date', 'start_time', 'end_time','type','client_id','parent_id','email'], 'safe'],
             ['end_time', DateTimeCompareValidator::className(), 'compareAttribute' => "start_time", 'format' => 'h:i A','jsFormat'=>'h:i A','operator' => '>='],
             ['appointment_date', DateTimeCompareValidator::className(), 'compareValue' => date('Y-m-d'),'operator' => '>=','format' =>'Y-m-d','on' => 'create'],
             [['worksite','billing' ], 'string', 'max' => 200]
        ];
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Client info model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getClientInfo() {
        // Vendor has_one Supply item via supply.manufacturerVendor -> vendor_id
        return $this->hasOne(ClientInfo::className(), ['id' => 'client_id']);
    }
    
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Appontment Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTasks() {
        // Appointment has_many Task via appointmen.id -> a_id
        return $this->hasMany(AppointmentTasks::className(), ['a_id' => 'id']) ;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Appontment Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSupply() {
        // Appointment has_many Task via appointmen.id -> a_id
        return $this->hasMany(AppointmentShoppingList::className(), ['appointment_id' => 'id']) ;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Appontment Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEquipment() {
        // Appointment has_many Task via appointmen.id -> a_id
        return $this->hasMany(AppointmentEquipmentList::className(), ['appointment_id' => 'id']) ;
    }
    /**
     * @author Santosh Kunjir <s.kunjir@splendornet.com>
     * Relation with Appontment Task model.
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCalenderCityCount() {
        return Yii::$app
                        ->db
                        ->createCommand('Select CONCAT(location.city," ", location.zipcode, " ", "(", COUNT(appointment.id) ,")" ) AS text '
                        . 'From location JOIN client_info on client_info.city=location.id '
                        . ' JOIN appointment on appointment.client_id = client_info.id '
                        . ' Where location.id like "%' . $cityData. '%" AND '
                        . 'appointment.appointment_date >= now()-interval 2 month AND appointment.appointment_date <= now()+ interval 2 month'
                        . ' GROUP BY location.city'
                        . Yii::$app->params['DROPDOWN_SIZE'])->queryScalar();
    }
   
    
       /**
     * Show formletter to send appointment.
     * @return redirect to client page
     */
    public function getInvoiceAppointment($id) {
       return Appointment::find()->andWhere(['client_id'=>$id,'type'=>'work_order','status'=>'confirmed'])->asArray()->all();
   }
   
    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'client_id' => 'Client',
            'status' => 'Status',
            'type' => 'Type',
            'appointment_date' => 'Appointment Date',
            'title' => 'Title',
            'start_time' => 'Start Time',
            'end_time' => 'End Time',
            'description' => 'Description',
            'worksite' => 'Worksite Address',
            'billing' => 'Billing Address',
            'property_id' => 'Property',
            'create_at' => 'Create At',
            'updated_at' => 'Updated At',
            'created_by' => 'Created By',
        ];
    }
}
